﻿using API_DB.Models.Data;
using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_DB.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class MatriculaController : ControllerBase
    {
        private readonly ILogger<MatriculaController> _logger;
        private MatriculaDB _matriculaDB;

        public MatriculaController(ILogger<MatriculaController> logger, MatriculaDB matriculaDB)
        {
            _logger = logger;
            _matriculaDB = matriculaDB;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<MatriculaViewModels>>> getMatriculas()
        {
            try
            {
                var dados = await _matriculaDB.listar();
                if (dados != null)
                    return Ok(dados);
                else return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possivel obter a lista de matricula" );
            }
        }

        [HttpGet("{IdAluno}/{IdCurso}")]
        public async Task<ActionResult<MatriculaViewModels>> getMatriculaById([FromRoute] int IdAluno, [FromRoute] int IdCurso)
        {
            try
            {
                var dados = await _matriculaDB.obterPorId(IdAluno, IdCurso);
                if (dados != null)
                    return Ok(dados);
                else
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("não foi possivel encontrar a matricula");
            }
        }

        [HttpPost]
        public async Task<ActionResult<MatriculaViewModels>> InsertMatricula([FromBody] MatriculaInputModel matricula)
        {
            try
            {
                var dados = await _matriculaDB.insert(matricula);
                return Ok(dados);
            }
            catch (Exception )
            {
                return UnprocessableEntity("nao foi possivel inserir matricula" );
            }
        }
        [HttpDelete("{IdAluno}/{IdCurso}")]
        public async Task<ActionResult<MatriculaViewModels>> Delete([FromRoute] int IdAluno, [FromRoute] int IdCurso )
        {
            try
            {
                var dados = await _matriculaDB.delete(IdAluno, IdCurso);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("não foi possivel deletar a matricula");
            }
        }


    }
}
