﻿using API_DB.Models.Data;
using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_DB.Controllers
{
    [Route("api/v1[controller]")]
    [ApiController]
    public class TipoAlunoController : ControllerBase
    {
        private readonly ILogger<TipoAlunoController> _logger;
        private readonly TipoAlunoDB _tipoAlunoDB;

        public TipoAlunoController(ILogger<TipoAlunoController> logger, TipoAlunoDB tipoAlunoDB)
        {
            _logger = logger;
            this._tipoAlunoDB = tipoAlunoDB;

        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<TipoAlunoViewModel>>> getTipos()
        {
            try
            {
                var dados = await _tipoAlunoDB.listar();
                if (dados != null)
                    return Ok(dados);
                else return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível obter a lista de tipo");
            }
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<TipoAlunoViewModel>> getTipoById([FromRoute] int Id)
        {
            try
            {
                var dados = await _tipoAlunoDB.obterPorId(Id);
                if (dados != null)
                    return Ok(dados);
                else
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível encontar o tipo!");
            }

        }

        [HttpPost]
        public async Task<ActionResult<TipoAlunoViewModel>> InserTipo(
            [FromBody] TipoAlunoInputModel Tipo
        )
        {
            try
            {
                var dados = await _tipoAlunoDB.insert(Tipo);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível inserir o tipo!");
            }
        }

        [HttpPut("{Id}")]
        public async Task<ActionResult<TipoAlunoViewModel>> UpdateTipo(
            [FromRoute] int Id, [FromBody] TipoAlunoInputModel Tipo
            )
        {
            try
            {
                var dados = await _tipoAlunoDB.update(Id, Tipo);
                return Ok(dados);
            }
            catch (Exception e)
            {
                return UnprocessableEntity("Não foi possível atualizar o tipo!" + e);
            }

        }

        [HttpDelete("{Id}")]
        public async Task<ActionResult<TipoAlunoViewModel>> Delete([FromRoute] int Id)
        {
            try
            {
                var dados = await _tipoAlunoDB.delete(Id);
                return Ok(dados);
            }
            catch (Exception )
            {
                return UnprocessableEntity("Não é possível excluir o tipo!" );
            }
        }



    }
}
   
