﻿using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using System.Data.SqlClient;

namespace API_DB.Models.Data
{
    public class MatriculaDB
    {
        private readonly IConexao _conexao;

        public MatriculaDB(IConexao conexao)
        {
            _conexao = conexao;
        }

        /* Implementar métodos para banco de dados */

        public async Task<List<MatriculaViewModels>> listar()
        {
            List<MatriculaViewModels> matriculas = new List<MatriculaViewModels>();

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                /*----------------------------------------------------------------- 
                Se o aluno não criou a view vWAlunos, utilize esse select 

                Select A.*, T.Tipo From tbAlunos A Inner Join tbTipoAluno T
		            On T.IdTipo = A.IdTipoAluno                  
                ------------------------------------------------------------------*/
                string query = "Select * from tbMatricula";
                SqlCommand command = new SqlCommand(query, conn);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        // Obter os dados e criar um objeto Aluno
                        MatriculaViewModels matricula = new MatriculaViewModels();
                        matricula.IdAluno = Int32.Parse(reader["IdAluno"].ToString());
                        matricula.DataMatricula = DateOnly.Parse(
                            reader["DataMatricula"].ToString().Substring(0, 10)
                        );
                        matricula.IdCurso = Int32.Parse(reader["IdCurso"].ToString()); ;

                        // Adicionando o novo Aluno na lista
                        matriculas.Add(matricula);
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return matriculas;
        }

        public async Task<MatriculaViewModels> obterPorId(int IdAluno, int IdCurso)
        {
            MatriculaViewModels matricula = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                /*----------------------------------------------------------------- 
                Se o aluno não criou a view vWAlunos, utilize esse select 

                Select A.*, T.Tipo From tbAlunos A Inner Join tbTipoAluno T
		            On T.IdTipo = A.IdTipoAluno Where IdAluno = @Id               
                ------------------------------------------------------------------*/
                string query = "Select * from tbMatricula Where IdAluno = @IdAluno and IdCurso = @IdCurso";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdAluno", IdAluno);
                command.Parameters.AddWithValue("@IdCurso", IdCurso);


                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        matricula = new MatriculaViewModels();

                        // Obter os dados e criar um objeto Aluno
                        matricula.IdAluno = Int32.Parse(reader["IdAluno"].ToString());
                        matricula.DataMatricula = DateOnly.Parse(
                            reader["DataMatricula"].ToString().Substring(0, 10)
                        );
                        matricula.IdCurso = Int32.Parse(reader["IdCurso"].ToString()); ;
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return matricula;
        }

        public async Task<MatriculaViewModels> obterMatricula(MatriculaInputModel matricula)
        {
            MatriculaViewModels matriculaAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Select Top 1 * from tbMatricula " +
                               "Where IdCurso = @IdCurso and IdAluno = @IdAluno " +
                               "Order By DataMatricula Desc";
                SqlCommand command = new SqlCommand(query, conn);
                //command.Parameters.AddWithValue("@DataMatricula", matricula.DataMatricula);
                command.Parameters.AddWithValue("@IdCurso", matricula.IdCurso);
                command.Parameters.AddWithValue("@IdAluno", matricula.IdAluno);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        matriculaAux = new MatriculaViewModels();

                        // Obter os dados e criar um objeto Aluno
                        matriculaAux.IdAluno = Int32.Parse(reader["IdAluno"].ToString());
                        matriculaAux.DataMatricula = DateOnly.Parse(
                            reader["DataMatricula"].ToString().Substring(0, 10)
                        );
                        matriculaAux.IdCurso = Int32.Parse(reader["IdCurso"].ToString()); ;
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return matriculaAux;
        }
        public async Task<MatriculaViewModels> insert(MatriculaInputModel matricula)
        {
            MatriculaViewModels matriculaAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Insert Into tbMatricula (IdAluno, DataMatricula,IdCurso) " +
                               "Values (@IdAluno, @DataMatricula, @IdCurso)";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdAluno", matricula.IdAluno);
                command.Parameters.AddWithValue("@DataMatricula", matricula.DataMatricula.ToString());
                command.Parameters.AddWithValue("@IdCurso", matricula.IdCurso);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            matriculaAux = await obterMatricula(matricula);
            return matriculaAux;
        }
        public async Task<MatriculaViewModels> delete(int IdAluno, int IdCurso)
        {

            MatriculaViewModels matriculaAux = await obterPorId(IdAluno, IdCurso);

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Delete From tbMatricula Where IdAluno=@IdAluno and IdCurso = @IdCurso";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdAluno", IdAluno);
                command.Parameters.AddWithValue("@IdCurso", IdCurso);


                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            return matriculaAux;
        }
    }

}
