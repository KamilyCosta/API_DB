﻿namespace API_DB.Models.ViewModels
{
    public class MatriculaViewModels
    {
        public int IdAluno { get; set; }
        public int IdCurso { get; set; }
        public DateOnly DataMatricula { get; set; }

    }
}
